//
//  UIButton(HBDIC).h
//  UIDictionaryKitDemo
//
//  Created by Natoto on 16/3/20.
//  Copyright © 2016年 YY.COM. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface UIButton(HBDIC)

@end
