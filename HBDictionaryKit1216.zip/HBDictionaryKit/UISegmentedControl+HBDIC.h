//
//  UISegmentedControl+HBDIC.h
//  UIDictionaryKitDemo
//
//  Created by zeno on 16/3/21.
//  Copyright © 2016年 YY.COM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UISegmentedControl(HBDIC)

-(instancetype)configwithdictionary:(NSDictionary *)dictionary;
@end
