//
//  UITableView+HBDIC.h
//  UIDictionaryKitDemo
//
//  Created by Natoto on 16/3/26.
//  Copyright © 2016年 YY.COM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView(HBDIC)

@end
